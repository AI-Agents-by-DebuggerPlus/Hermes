<?php
/**
 * Plugin Name: Hermes Image Receiver
 * Plugin URI:  https://github.com/your-repo/hermes-image-receiver
 * Description: Receives screenshots from Hermes.Wpf via REST API and displays a real-time gallery via SSE.
 * Version:     1.1.0
 * Author:      Your Name
 * License:     GPL-2.0+
 * Text Domain: hermes-image-receiver
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'HIR_VERSION',     '1.1.0' );
define( 'HIR_PLUGIN_DIR',  plugin_dir_path( __FILE__ ) );
define( 'HIR_PLUGIN_URL',  plugin_dir_url( __FILE__ ) );
define( 'HIR_PLUGIN_FILE', __FILE__ );

require_once HIR_PLUGIN_DIR . 'includes/class-hir-activator.php';
require_once HIR_PLUGIN_DIR . 'includes/class-hir-settings.php';
require_once HIR_PLUGIN_DIR . 'includes/class-hir-rest-api.php';
require_once HIR_PLUGIN_DIR . 'includes/class-hir-shortcode.php';

register_activation_hook(   __FILE__, [ 'HIR_Activator', 'activate'   ] );
register_deactivation_hook( __FILE__, [ 'HIR_Activator', 'deactivate' ] );

function hir_init() {
    HIR_Settings::init();
    HIR_REST_API::init();
    HIR_Shortcode::init();
}
add_action( 'plugins_loaded', 'hir_init' );
