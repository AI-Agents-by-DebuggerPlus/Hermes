<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class HIR_Shortcode {

    public static function init() {
        add_shortcode( 'hermes_gallery', [ __CLASS__, 'render' ] );
        add_action( 'wp_enqueue_scripts', [ __CLASS__, 'register_assets' ] );
    }

    public static function register_assets() {
        wp_register_style(
            'hir-gallery',
            HIR_PLUGIN_URL . 'assets/css/gallery.css',
            [],
            HIR_VERSION
        );
        wp_register_script(
            'hir-gallery',
            HIR_PLUGIN_URL . 'assets/js/gallery.js',
            [],
            HIR_VERSION,
            true
        );
    }

    public static function render( $atts ) {
        $atts = shortcode_atts( [
            'channel'     => '',
            'max'         => 20,
            'autoconnect' => 'true',
            'ws_port'     => get_option( 'hir_ws_port', 8765 ),
            'layout'      => 'grid',   // grid | masonry | single
            'title'       => 'Hermes Live Feed',
        ], $atts, 'hermes_gallery' );

        wp_enqueue_style(  'hir-gallery' );
        wp_enqueue_script( 'hir-gallery' );

        $uid = 'hir-' . uniqid();

        wp_localize_script( 'hir-gallery', 'hirConfig_' . str_replace( '-', '_', $uid ), [
            'uid'         => $uid,
            'channel'     => sanitize_text_field( $atts['channel'] ),
            'max'         => absint( $atts['max'] ),
            'autoconnect' => $atts['autoconnect'] === 'true',
            'streamUrl'   => rest_url( 'hermes/v1/stream' ),
            'restUrl'     => rest_url( 'hermes/v1/' ),
            'layout'      => sanitize_text_field( $atts['layout'] ),
        ] );

        ob_start();
        ?>
        <div class="hir-gallery-wrap hir-layout-<?php echo esc_attr($atts['layout']); ?>"
             id="<?php echo esc_attr($uid); ?>"
             data-uid="<?php echo esc_attr($uid); ?>"
             data-channel="<?php echo esc_attr($atts['channel']); ?>"
             data-max="<?php echo esc_attr($atts['max']); ?>"
             data-autoconnect="<?php echo esc_attr($atts['autoconnect']); ?>"
             data-ws-port="<?php echo esc_attr($atts['ws_port']); ?>"
             data-layout="<?php echo esc_attr($atts['layout']); ?>">

            <div class="hir-header">
                <div class="hir-title">
                    <span class="hir-led" data-uid="<?php echo esc_attr($uid); ?>"></span>
                    <?php echo esc_html( $atts['title'] ); ?>
                    <?php if ($atts['channel']): ?>
                        <span class="hir-channel-badge"><?php echo esc_html($atts['channel']); ?></span>
                    <?php endif; ?>
                </div>
                <div class="hir-controls">
                    <span class="hir-counter" data-uid="<?php echo esc_attr($uid); ?>">0 фото</span>
                    <button class="hir-btn hir-btn-connect" data-uid="<?php echo esc_attr($uid); ?>">
                        Подключить
                    </button>
                    <button class="hir-btn hir-btn-clear" data-uid="<?php echo esc_attr($uid); ?>">
                        Очистить
                    </button>
                </div>
            </div>

            <div class="hir-status-bar">
                <span class="hir-status-msg" data-uid="<?php echo esc_attr($uid); ?>">
                    Подключение к SSE…
                </span>
            </div>

            <div class="hir-images" data-uid="<?php echo esc_attr($uid); ?>">
                <div class="hir-empty-state">
                    <div class="hir-empty-icon">📡</div>
                    <p>Ожидание изображений от Hermes.Wpf…</p>
                </div>
            </div>

            <!-- Lightbox -->
            <div class="hir-lightbox" data-uid="<?php echo esc_attr($uid); ?>" style="display:none;">
                <div class="hir-lightbox-overlay"></div>
                <div class="hir-lightbox-content">
                    <button class="hir-lightbox-close">✕</button>
                    <button class="hir-lightbox-prev">‹</button>
                    <button class="hir-lightbox-next">›</button>
                    <img class="hir-lightbox-img" src="" alt="" />
                    <div class="hir-lightbox-meta"></div>
                </div>
            </div>
        </div>
        <?php
        return ob_get_clean();
    }
}
