<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class HIR_Activator {

    public static function activate() {
        global $wpdb;

        $table   = $wpdb->prefix . 'hir_images';
        $charset = $wpdb->get_charset_collate();

        $sql = "CREATE TABLE IF NOT EXISTS {$table} (
            id          BIGINT(20) UNSIGNED NOT NULL AUTO_INCREMENT,
            channel     VARCHAR(100)        NOT NULL DEFAULT 'default',
            filename    VARCHAR(255)        NOT NULL,
            mime_type   VARCHAR(100)        NOT NULL DEFAULT 'image/png',
            image_data  LONGBLOB,
            file_path   VARCHAR(500)        DEFAULT NULL,
            meta        TEXT                DEFAULT NULL,
            created_at  DATETIME            NOT NULL DEFAULT CURRENT_TIMESTAMP,
            PRIMARY KEY (id),
            KEY channel (channel),
            KEY created_at (created_at)
        ) {$charset};";

        require_once ABSPATH . 'wp-admin/includes/upgrade.php';
        dbDelta( $sql );

        // Default options
        $defaults = [
            'hir_ws_port'          => 8765,
            'hir_ws_host'          => '0.0.0.0',
            'hir_max_images'       => 50,
            'hir_save_to_disk'     => 1,
            'hir_upload_subdir'    => 'hermes-images',
            'hir_allowed_channels' => '',
            'hir_secret_token'     => wp_generate_password( 32, false ),
        ];
        foreach ( $defaults as $key => $val ) {
            if ( false === get_option( $key ) ) {
                add_option( $key, $val );
            }
        }

        add_option( 'hir_db_version', HIR_VERSION );
    }

    public static function deactivate() {
        // Intentionally left blank – keep data on deactivation
    }
}
