<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class HIR_REST_API {

    public static function init() {
        add_action( 'rest_api_init', [ __CLASS__, 'register_routes' ] );
        add_filter( 'rest_pre_serve_request', [ __CLASS__, 'rest_pre_serve_request' ], 10, 4 );
    }

    public static function rest_pre_serve_request( $served, $result, $request, $server ) {
        if ( $request->get_route() === '/hermes/v1/stream' ) {
            return true;
        }
        return $served;
    }

    public static function register_routes() {
        // Receive image via REST (Hermes.Wpf → WordPress)
        register_rest_route( 'hermes/v1', '/image', [
            'methods'             => 'POST',
            'callback'            => [ __CLASS__, 'receive_image' ],
            'permission_callback' => '__return_true',
        ] );

        // SSE stream for live gallery (browser EventSource)
        register_rest_route( 'hermes/v1', '/stream', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'stream' ],
            'permission_callback' => '__return_true',
        ] );

        // Get recent images (used by admin page & frontend polling fallback)
        register_rest_route( 'hermes/v1', '/images', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_images' ],
            'permission_callback' => '__return_true',
        ] );

        // Delete all images
        register_rest_route( 'hermes/v1', '/images', [
            'methods'             => 'DELETE',
            'callback'            => [ __CLASS__, 'delete_images' ],
            'permission_callback' => [ __CLASS__, 'verify_admin' ],
        ] );

        // Server status
        register_rest_route( 'hermes/v1', '/status', [
            'methods'             => 'GET',
            'callback'            => [ __CLASS__, 'get_status' ],
            'permission_callback' => '__return_true',
        ] );
    }

    // -------------------------------------------------------------------------
    // Receive image
    // -------------------------------------------------------------------------
    public static function receive_image( WP_REST_Request $request ) {
        $body = $request->get_json_params();

        // Token validation
        $token = $body['token'] ?? $request->get_header('X-Hermes-Token') ?? '';
        if ( ! hash_equals( get_option( 'hir_secret_token', '' ), $token ) ) {
            return new WP_REST_Response( [ 'error' => 'Unauthorized' ], 401 );
        }

        $channel   = sanitize_text_field( $body['channel']  ?? 'default' );
        $filename  = sanitize_file_name(  $body['filename'] ?? 'image.png' );
        $mime      = sanitize_text_field( $body['mime']     ?? 'image/png' );
        $b64data   = $body['data'] ?? $body['image_base64'] ?? '';
        $meta      = is_array( $body['meta'] ?? null ) ? $body['meta'] : [];

        $sender = sanitize_text_field( $body['sender'] ?? '' );
        if ( $sender !== '' ) {
            $meta['sender'] = $sender;
        }

        // Validate channel
        $allowed = get_option( 'hir_allowed_channels', '' );
        if ( ! empty( $allowed ) ) {
            $list = array_map( 'trim', explode( ',', $allowed ) );
            if ( ! in_array( $channel, $list, true ) ) {
                return new WP_REST_Response( [ 'error' => 'Channel not allowed' ], 403 );
            }
        }

        // Decode image
        $image_data = base64_decode( $b64data );
        if ( $image_data === false || strlen( $image_data ) < 10 ) {
            return new WP_REST_Response( [ 'error' => 'Invalid image data' ], 400 );
        }

        global $wpdb;
        $table     = $wpdb->prefix . 'hir_images';
        $file_path = null;

        // Optionally save to disk
        if ( get_option( 'hir_save_to_disk', 1 ) ) {
            $file_path = self::save_image_to_disk( $image_data, $filename, $mime );
        }

        $wpdb->insert( $table, [
            'channel'    => $channel,
            'filename'   => $filename,
            'mime_type'  => $mime,
            'image_data' => $file_path ? null : $image_data, // only store blob if not on disk
            'file_path'  => $file_path,
            'meta'       => wp_json_encode( $meta ),
            'created_at' => current_time( 'mysql' ),
        ], [ '%s', '%s', '%s', '%s', '%s', '%s', '%s' ] );

        $id = $wpdb->insert_id;

        // Trim old records
        $max = (int) get_option( 'hir_max_images', 50 );
        $wpdb->query( $wpdb->prepare(
            "DELETE FROM {$table} WHERE id NOT IN (
                SELECT id FROM (SELECT id FROM {$table} ORDER BY id DESC LIMIT %d) tmp
            )",
            $max
        ) );

        // Build public URL
        $url = $file_path ? self::path_to_url( $file_path ) : rest_url( "hermes/v1/image-data/{$id}" );

        return new WP_REST_Response( [
            'success' => true,
            'id'      => $id,
            'url'     => $url,
            'channel' => $channel,
        ], 201 );
    }

    // -------------------------------------------------------------------------
    // Get images list
    // -------------------------------------------------------------------------
    public static function get_images( WP_REST_Request $request ) {
        global $wpdb;
        $table   = $wpdb->prefix . 'hir_images';
        $channel = sanitize_text_field( $request->get_param( 'channel' ) ?? '' );
        $since   = absint( $request->get_param( 'since' ) ?? 0 ); // last seen ID
        $limit   = min( absint( $request->get_param( 'limit' ) ?? 20 ), 100 );

        $where = $since ? $wpdb->prepare( 'WHERE id > %d', $since ) : '';
        if ( $channel ) {
            $where = $where
                ? $where . $wpdb->prepare( ' AND channel = %s', $channel )
                : $wpdb->prepare( 'WHERE channel = %s', $channel );
        }

        $rows = $wpdb->get_results( $wpdb->prepare(
            "SELECT id, channel, filename, mime_type, file_path, meta, created_at
             FROM {$table} {$where} ORDER BY id DESC LIMIT %d",
            $limit
        ) );

        $images = [];
        foreach ( $rows as $row ) {
            $url = $row->file_path
                ? self::path_to_url( $row->file_path )
                : rest_url( "hermes/v1/image-data/{$row->id}" );

            $images[] = [
                'id'         => (int) $row->id,
                'channel'    => $row->channel,
                'filename'   => $row->filename,
                'mime_type'  => $row->mime_type,
                'url'        => $url,
                'meta'       => json_decode( $row->meta ?? '{}' ),
                'created_at' => $row->created_at,
            ];
        }

        return new WP_REST_Response( [ 'images' => $images ], 200 );
    }

    // -------------------------------------------------------------------------
    // SSE stream (same pattern as WPFtoWordPressSSE realtime-receiver)
    // -------------------------------------------------------------------------
    public static function stream() {
        header( 'Content-Type: text/event-stream' );
        header( 'Cache-Control: no-cache' );
        header( 'Connection: keep-alive' );

        @ini_set( 'output_buffering', 'off' );
        @ini_set( 'zlib.output_compression', false );

        while ( ob_get_level() ) {
            ob_end_flush();
        }

        global $wpdb;
        $table   = $wpdb->prefix . 'hir_images';
        $last_id = isset( $_GET['last_id'] ) ? absint( $_GET['last_id'] ) : 0;
        $channel = isset( $_GET['channel'] ) ? sanitize_text_field( wp_unslash( $_GET['channel'] ) ) : '';

        ignore_user_abort( true );

        while ( ! connection_aborted() ) {
            if ( $channel !== '' ) {
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT * FROM {$table} WHERE id > %d AND channel = %s ORDER BY id ASC",
                    $last_id,
                    $channel
                ) );
            } else {
                $rows = $wpdb->get_results( $wpdb->prepare(
                    "SELECT * FROM {$table} WHERE id > %d ORDER BY id ASC",
                    $last_id
                ) );
            }

            foreach ( $rows as $row ) {
                $last_id = (int) $row->id;
                $url     = $row->file_path
                    ? self::path_to_url( $row->file_path )
                    : rest_url( "hermes/v1/image-data/{$row->id}" );

                $meta = json_decode( $row->meta ?? '{}', true );
                if ( ! is_array( $meta ) ) {
                    $meta = [];
                }

                echo "id: {$row->id}\n";
                echo 'data: ' . wp_json_encode( [
                    'id'         => (int) $row->id,
                    'type'       => 'image',
                    'channel'    => $row->channel,
                    'sender'     => $meta['sender'] ?? '',
                    'filename'   => $row->filename,
                    'image_url'  => $url,
                    'meta'       => $meta,
                    'created_at' => $row->created_at,
                ] ) . "\n\n";

                flush();
            }

            echo ": ping\n\n";
            flush();
            sleep( 1 );
        }

        exit;
    }

    // -------------------------------------------------------------------------
    // Serve raw image blob from DB
    // -------------------------------------------------------------------------
    public static function serve_image_data( WP_REST_Request $request ) {
        global $wpdb;
        $id  = absint( $request['id'] );
        $row = $wpdb->get_row( $wpdb->prepare(
            "SELECT image_data, mime_type FROM {$wpdb->prefix}hir_images WHERE id = %d", $id
        ) );
        if ( ! $row || ! $row->image_data ) {
            return new WP_REST_Response( [ 'error' => 'Not found' ], 404 );
        }
        header( 'Content-Type: ' . $row->mime_type );
        header( 'Content-Length: ' . strlen( $row->image_data ) );
        echo $row->image_data; // phpcs:ignore
        exit;
    }

    public static function delete_images( WP_REST_Request $request ) {
        global $wpdb;
        $wpdb->query( "TRUNCATE TABLE {$wpdb->prefix}hir_images" );
        return new WP_REST_Response( [ 'success' => true ], 200 );
    }

    public static function get_status() {
        return new WP_REST_Response( [
            'status'     => 'ok',
            'version'    => HIR_VERSION,
            'stream_url' => rest_url( 'hermes/v1/stream' ),
            'port'       => (int) get_option( 'hir_ws_port', 8765 ),
        ], 200 );
    }

    public static function verify_admin() {
        return current_user_can( 'manage_options' );
    }

    // -------------------------------------------------------------------------
    // Helpers
    // -------------------------------------------------------------------------
    private static function save_image_to_disk( $data, $filename, $mime ) {
        $upload  = wp_upload_dir();
        $subdir  = trim( get_option( 'hir_upload_subdir', 'hermes-images' ), '/' );
        $dir     = $upload['basedir'] . '/' . $subdir . '/' . date( 'Y/m' );

        wp_mkdir_p( $dir );

        // Unique filename
        $ext   = self::mime_to_ext( $mime );
        $base  = pathinfo( $filename, PATHINFO_FILENAME );
        $path  = $dir . '/' . $base . '-' . uniqid() . '.' . $ext;

        file_put_contents( $path, $data );
        return $path;
    }

    private static function path_to_url( $path ) {
        $upload = wp_upload_dir();
        return str_replace( $upload['basedir'], $upload['baseurl'], $path );
    }

    private static function mime_to_ext( $mime ) {
        $map = [
            'image/png'  => 'png',
            'image/jpeg' => 'jpg',
            'image/webp' => 'webp',
            'image/gif'  => 'gif',
            'image/bmp'  => 'bmp',
        ];
        return $map[ $mime ] ?? 'png';
    }
}
