/**
 * Hermes Image Receiver — Frontend Gallery
 * SSE (EventSource) live feed + REST polling fallback + lightbox
 */
(function () {
  'use strict';

  const galleries = {};

  function initAll() {
    document.querySelectorAll('.hir-gallery-wrap').forEach(initGallery);
  }

  function initGallery(wrap) {
    const uid = wrap.dataset.uid;
    if (galleries[uid]) return;

    const cfgKey = 'hirConfig_' + uid.replace(/-/g, '_');
    const cfg = window[cfgKey] || {};

    const state = {
      uid,
      wrap,
      eventSource: null,
      pollTimer: null,
      connected: false,
      images: [],
      lightboxIdx: -1,
      channel: cfg.channel || wrap.dataset.channel || '',
      max: parseInt(cfg.max || wrap.dataset.max || 20, 10),
      autoconnect: (cfg.autoconnect !== undefined ? cfg.autoconnect : wrap.dataset.autoconnect) !== 'false',
      streamUrl: cfg.streamUrl || '/wp-json/hermes/v1/stream',
      restUrl: cfg.restUrl || '/wp-json/hermes/v1/',
      layout: cfg.layout || 'grid',
      lastId: 0,
    };

    galleries[uid] = state;
    bindControls(state);

    if (state.autoconnect) {
      connectSSE(state);
    }

    fetchImages(state);
  }

  function connectSSE(state) {
    if (state.eventSource) return;

    setLed(state, 'connecting');
    setStatus(state, 'Подключение к SSE…');

    let url = state.streamUrl;
    const sep = url.indexOf('?') >= 0 ? '&' : '?';
    url += sep + 'last_id=' + state.lastId;
    if (state.channel) {
      url += '&channel=' + encodeURIComponent(state.channel);
    }

    let source;
    try {
      source = new EventSource(url);
    } catch (e) {
      setLed(state, 'error');
      setStatus(state, 'Ошибка SSE: ' + e.message + '. Используется REST-опрос.');
      startPolling(state);
      return;
    }

    state.eventSource = source;

    source.onopen = function () {
      state.connected = true;
      setLed(state, 'connected');
      setStatus(state, 'Подключено (SSE). Ожидание скриншотов от Hermes.Wpf…');
      updateConnectBtn(state, true);
      stopPolling(state);
    };

    source.onmessage = function (event) {
      try {
        handleStreamMessage(state, JSON.parse(event.data));
      } catch (e) {
        // ignore
      }
    };

    source.onerror = function () {
      disconnectSSE(state, false);
      setLed(state, 'error');
      setStatus(state, 'SSE отключён. REST-опрос…');
      startPolling(state);
      setTimeout(function () {
        if (galleries[state.uid] && !state.eventSource) {
          connectSSE(state);
        }
      }, 5000);
    };
  }

  function disconnectSSE(state, userInitiated) {
    stopPolling(state);
    if (state.eventSource) {
      state.eventSource.close();
      state.eventSource = null;
    }
    state.connected = false;
    setLed(state, '');
    if (userInitiated) {
      setStatus(state, 'Отключено.');
    }
    updateConnectBtn(state, false);
  }

  function handleStreamMessage(state, data) {
    if (data.type !== 'image' && !data.image_url) return;
    if (state.channel && data.channel && data.channel !== state.channel) return;

    const url = data.image_url || data.url;
    if (!url) return;

    const meta = data.meta || {};
    if (data.sender && !meta.sender) {
      meta.sender = data.sender;
    }

    prependImage(state, {
      id: data.id || Date.now(),
      url: url,
      channel: data.channel || 'default',
      filename: data.filename || 'image.png',
      created_at: data.created_at || new Date().toISOString(),
      meta: meta,
    });
  }

  function startPolling(state) {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(function () {
      fetchImages(state);
    }, 3000);
  }

  function stopPolling(state) {
    if (state.pollTimer) {
      clearInterval(state.pollTimer);
      state.pollTimer = null;
    }
  }

  function fetchImages(state) {
    let url = state.restUrl + 'images?limit=20';
    if (state.channel) url += '&channel=' + encodeURIComponent(state.channel);
    if (state.lastId) url += '&since=' + state.lastId;

    fetch(url)
      .then(function (r) { return r.ok ? r.json() : null; })
      .then(function (data) {
        if (!data || !data.images) return;
        const items = data.images.slice().reverse();
        items.forEach(function (img) {
          prependImage(state, img, false);
        });
        if (items.length) {
          const maxId = Math.max.apply(null, items.map(function (i) { return i.id; }));
          state.lastId = Math.max(state.lastId, maxId);
        }
      })
      .catch(function () {});
  }

  function prependImage(state, item, flash) {
    if (state.images.find(function (i) { return i.id === item.id; })) return;

    state.images.unshift(item);
    if (state.images.length > state.max) {
      state.images = state.images.slice(0, state.max);
    }

    if (typeof item.id === 'number') {
      state.lastId = Math.max(state.lastId, item.id);
    }

    renderGallery(state, flash === false ? null : item.id);
  }

  function renderGallery(state, flashId) {
    const container = state.wrap.querySelector('.hir-images[data-uid="' + state.uid + '"]');
    if (!container) return;

    const empty = container.querySelector('.hir-empty-state');
    if (empty) empty.remove();

    const existing = new Map();
    container.querySelectorAll('.hir-img-item').forEach(function (el) {
      existing.set(el.dataset.id, el);
    });

    existing.forEach(function (el, id) {
      if (!state.images.find(function (i) { return String(i.id) === id; })) el.remove();
    });

    state.images.forEach(function (img, idx) {
      const idStr = String(img.id);
      let el = existing.get(idStr);
      if (!el) {
        el = buildImageEl(state, img, idx);
        const ref = container.children[idx] || null;
        container.insertBefore(el, ref);
      }
      if (img.id === flashId) {
        el.classList.remove('hir-new');
        void el.offsetWidth;
        el.classList.add('hir-new');
      }
    });

    const counter = state.wrap.querySelector('.hir-counter[data-uid="' + state.uid + '"]');
    if (counter) counter.textContent = state.images.length + ' фото';
  }

  function buildImageEl(state, img, idx) {
    const el = document.createElement('div');
    el.className = 'hir-img-item';
    el.dataset.id = String(img.id);
    el.dataset.idx = idx;

    const time = formatTime(img.created_at);
    const sender = (img.meta && img.meta.sender) ? ' · ' + escHtml(img.meta.sender) : '';

    el.innerHTML =
      '<img src="' + escHtml(img.url) + '" alt="' + escHtml(img.filename) + '" loading="lazy" />' +
      '<div class="hir-img-meta">' +
      '<span class="hir-img-channel">#' + escHtml(img.channel) + sender + '</span>' +
      '<span>' + escHtml(time) + '</span>' +
      '</div>';

    el.addEventListener('click', function () { openLightbox(state, idx); });
    return el;
  }

  function openLightbox(state, idx) {
    state.lightboxIdx = idx;
    const lb = state.wrap.querySelector('.hir-lightbox[data-uid="' + state.uid + '"]');
    if (!lb) return;
    lb.style.display = 'flex';
    renderLightbox(state);
    document.addEventListener('keydown', state._lbKey = function (e) {
      if (e.key === 'ArrowRight') {
        state.lightboxIdx = (state.lightboxIdx + 1) % state.images.length;
        renderLightbox(state);
      }
      if (e.key === 'ArrowLeft') {
        state.lightboxIdx = (state.lightboxIdx - 1 + state.images.length) % state.images.length;
        renderLightbox(state);
      }
      if (e.key === 'Escape') closeLightbox(state);
    });
  }

  function renderLightbox(state) {
    const lb = state.wrap.querySelector('.hir-lightbox[data-uid="' + state.uid + '"]');
    if (!lb) return;
    const img = state.images[state.lightboxIdx];
    if (!img) return;
    lb.querySelector('.hir-lightbox-img').src = img.url;
    const m = img.meta || {};
    lb.querySelector('.hir-lightbox-meta').textContent =
      [img.filename, m.width ? m.width + '×' + m.height : '', formatTime(img.created_at)]
        .filter(Boolean)
        .join(' · ');
  }

  function closeLightbox(state) {
    const lb = state.wrap.querySelector('.hir-lightbox[data-uid="' + state.uid + '"]');
    if (lb) lb.style.display = 'none';
    if (state._lbKey) document.removeEventListener('keydown', state._lbKey);
  }

  function bindControls(state) {
    const uid = state.uid;

    const btnConn = state.wrap.querySelector('.hir-btn-connect[data-uid="' + uid + '"]');
    if (btnConn) {
      btnConn.addEventListener('click', function () {
        if (state.connected || state.eventSource) {
          disconnectSSE(state, true);
        } else {
          connectSSE(state);
        }
      });
    }

    const btnClear = state.wrap.querySelector('.hir-btn-clear[data-uid="' + uid + '"]');
    if (btnClear) {
      btnClear.addEventListener('click', function () {
        state.images = [];
        state.lastId = 0;
        const container = state.wrap.querySelector('.hir-images[data-uid="' + uid + '"]');
        if (container) {
          container.innerHTML =
            '<div class="hir-empty-state">' +
            '<div class="hir-empty-icon">📡</div>' +
            '<p>Ожидание изображений от Hermes.Wpf…</p>' +
            '</div>';
        }
        const counter = state.wrap.querySelector('.hir-counter[data-uid="' + uid + '"]');
        if (counter) counter.textContent = '0 фото';
      });
    }

    const lb = state.wrap.querySelector('.hir-lightbox[data-uid="' + uid + '"]');
    if (lb) {
      lb.querySelector('.hir-lightbox-close').addEventListener('click', function () { closeLightbox(state); });
      lb.querySelector('.hir-lightbox-overlay').addEventListener('click', function () { closeLightbox(state); });
      lb.querySelector('.hir-lightbox-prev').addEventListener('click', function () {
        state.lightboxIdx = (state.lightboxIdx - 1 + state.images.length) % state.images.length;
        renderLightbox(state);
      });
      lb.querySelector('.hir-lightbox-next').addEventListener('click', function () {
        state.lightboxIdx = (state.lightboxIdx + 1) % state.images.length;
        renderLightbox(state);
      });
    }
  }

  function setLed(state, cls) {
    state.wrap.querySelectorAll('.hir-led[data-uid="' + state.uid + '"]').forEach(function (el) {
      el.className = 'hir-led ' + cls;
    });
  }

  function setStatus(state, msg) {
    state.wrap.querySelectorAll('.hir-status-msg[data-uid="' + state.uid + '"]').forEach(function (el) {
      el.textContent = msg;
    });
  }

  function updateConnectBtn(state, isConnected) {
    state.wrap.querySelectorAll('.hir-btn-connect[data-uid="' + state.uid + '"]').forEach(function (btn) {
      btn.textContent = isConnected ? 'Отключить' : 'Подключить';
      btn.classList.toggle('active', isConnected);
    });
  }

  function formatTime(iso) {
    try {
      return new Date(iso).toLocaleTimeString('ru-RU', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
      });
    } catch (e) {
      return '';
    }
  }

  function escHtml(s) {
    return String(s)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;');
  }

  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  window.HermesReceiver = { initAll, galleries };
})();
