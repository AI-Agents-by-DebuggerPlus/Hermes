/* Hermes Image Receiver — Admin JS */
jQuery(function ($) {
  var cfg = window.hirAdmin || {};

  // Status check
  function checkStatus() {
    fetch(cfg.restUrl + 'status')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data && data.status === 'ok') {
          $('#hir-status-dot').addClass('ok').removeClass('error');
          var sse = data.sse ? 'SSE включён' : 'SSE выключен';
          $('#hir-status-text').text('REST API доступен. ' + sse + '. v' + (data.version || '?'));
        } else {
          throw new Error('bad');
        }
      })
      .catch(() => {
        $('#hir-status-dot').addClass('error').removeClass('ok');
        $('#hir-status-text').text('REST API недоступен');
      });
  }

  checkStatus();
  $('#hir-refresh-status').on('click', checkStatus);

  // Regen token
  $('#hir-regen-token').on('click', function () {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var token = Array.from({length: 32}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    $('#hir-token-field').val(token).removeAttr('readonly');
  });

  // Lightbox
  var $lightbox = $('<div id="hir-lightbox"><span id="hir-lightbox-close">&times;</span><img id="hir-lightbox-img" src="" alt="" /></div>');
  $('body').append($lightbox);
  $lightbox.on('click', function (e) {
    if (e.target === $lightbox[0] || e.target.id === 'hir-lightbox-close') {
      $lightbox.hide();
    }
  });
  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') { $lightbox.hide(); }
  });

  // Load recent images
  function loadRecent() {
    fetch(cfg.restUrl + 'images?limit=12', { credentials: 'same-origin' })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        var $wrap = $('#hir-recent-images');
        if (!data || !data.images || !data.images.length) {
          $wrap.html('<p>Изображений пока нет</p>');
          return;
        }
        $wrap.empty();
        data.images.forEach(function (img) {
          var safeUrl = $('<div>').text(img.url).html();
          var $img = $('<img src="' + safeUrl + '" title="' + img.filename + '" alt="' + img.filename + '" />');
          $img.on('click', function () {
            $('#hir-lightbox-img').attr('src', img.url);
            $lightbox.show();
          });
          $wrap.append($img);
        });
      })
      .catch(() => { $('#hir-recent-images').html('<p>Ошибка загрузки</p>'); });
  }

  loadRecent();

  // Clear all
  $('#hir-clear-all').on('click', function () {
    if (!confirm('Удалить все записи из БД?')) return;
    fetch(cfg.restUrl + 'images', {
      method: 'DELETE',
      credentials: 'same-origin',
      headers: {
        'X-WP-Nonce': cfg.nonce,
        'Content-Type': 'application/json'
      }
    })
      .then(function (r) {
        if (!r.ok) {
          r.json().then(function (d) {
            alert('Ошибка удаления: ' + (d.message || r.status));
          }).catch(function () {
            alert('Ошибка удаления: ' + r.status);
          });
          return;
        }
        loadRecent();
      })
      .catch(function () { alert('Сетевая ошибка при удалении'); });
  });
});
