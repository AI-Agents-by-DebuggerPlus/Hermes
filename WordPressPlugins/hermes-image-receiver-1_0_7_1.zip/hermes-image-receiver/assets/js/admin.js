/* Hermes Image Receiver — Admin JS */
jQuery(function ($) {
  var cfg = window.hirAdmin || {};

  // ── Lightbox ────────────────────────────────────────────────────────────────
  var $lightbox = $(
    '<div id="hir-lightbox" style="display:none;position:fixed;inset:0;z-index:99999;' +
    'background:rgba(0,0,0,.92);cursor:zoom-out;align-items:center;justify-content:center;">' +
    '<img id="hir-lightbox-img" style="max-width:95vw;max-height:95vh;object-fit:contain;' +
    'box-shadow:0 0 40px rgba(0,0,0,.8);border-radius:4px;" />' +
    '<span id="hir-lightbox-close" style="position:absolute;top:16px;right:24px;' +
    'font-size:36px;color:#fff;cursor:pointer;line-height:1;user-select:none;">&times;</span>' +
    '</div>'
  ).appendTo('body');

  function openLightbox(src) {
    $('#hir-lightbox-img').attr('src', src);
    $lightbox.css('display', 'flex');
    $('body').css('overflow', 'hidden');
  }

  function closeLightbox() {
    $lightbox.hide();
    $('body').css('overflow', '');
  }

  $lightbox.on('click', function (e) {
    if (e.target === this || e.target.id === 'hir-lightbox-close') {
      closeLightbox();
    }
  });

  $(document).on('keydown', function (e) {
    if (e.key === 'Escape') closeLightbox();
  });

  // ── Status check ────────────────────────────────────────────────────────────
  function checkStatus() {
    fetch(cfg.restUrl + 'status')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (data && data.status === 'ok') {
          $('#hir-status-dot').addClass('ok').removeClass('error');
          var sse = data.sse ? 'SSE включён' : 'SSE выключен';
          $('#hir-status-text').text('REST API доступен. ' + sse + '. v' + (data.version || '?'));
        } else {
          throw new Error('bad');
        }
      })
      .catch(() => {
        $('#hir-status-dot').addClass('error').removeClass('ok');
        $('#hir-status-text').text('REST API недоступен');
      });
  }

  checkStatus();
  $('#hir-refresh-status').on('click', checkStatus);

  // ── Regen token ─────────────────────────────────────────────────────────────
  $('#hir-regen-token').on('click', function () {
    var chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    var token = Array.from({length: 32}, () => chars[Math.floor(Math.random() * chars.length)]).join('');
    $('#hir-token-field').val(token).removeAttr('readonly');
  });

  // ── Load recent images ───────────────────────────────────────────────────────
  function loadRecent() {
    fetch(cfg.restUrl + 'images?limit=12')
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        var $wrap = $('#hir-recent-images');
        if (!data || !data.images || !data.images.length) {
          $wrap.html('<p>Изображений пока нет</p>');
          return;
        }
        $wrap.empty();
        data.images.forEach(function (img) {
          var escapedUrl  = $('<div>').text(img.url).html();
          var escapedName = $('<div>').text(img.filename).html();
          var $thumb = $(
            '<img src="' + escapedUrl + '" title="' + escapedName + '" ' +
            'style="cursor:zoom-in;" />'
          );
          $thumb.on('click', function () { openLightbox(img.url); });
          $wrap.append($thumb);
        });
      })
      .catch(() => { $('#hir-recent-images').html('<p>Ошибка загрузки</p>'); });
  }

  loadRecent();

  // ── Clear all (БД + файлы на сервере) ───────────────────────────────────────
  $('#hir-clear-all').on('click', function () {
    if (!confirm('Удалить все изображения из БД и с сервера?')) return;
    fetch(cfg.restUrl + 'images', {
      method: 'DELETE',
      headers: { 'X-WP-Nonce': cfg.nonce }
    }).then(function (r) {
      if (!r.ok) { alert('Ошибка удаления: ' + r.status); }
      loadRecent();
    }).catch(function () {
      alert('Ошибка соединения при удалении');
      loadRecent();
    });
  });
});
