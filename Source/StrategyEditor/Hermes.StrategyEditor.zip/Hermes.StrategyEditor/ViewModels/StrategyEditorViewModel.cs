using System.Collections.ObjectModel;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using Hermes.StrategyEditor.Models;
using Hermes.StrategyEditor.Services;

namespace Hermes.StrategyEditor.ViewModels;

public partial class StrategyEditorViewModel : ObservableObject
{
    private readonly StrategyStorageService _storage;
    private readonly HermesAgentService _agent;

    // ── Constructor ──────────────────────────────────────────────────────────

    public StrategyEditorViewModel(
        StrategyStorageService storage,
        HermesAgentService agent)
    {
        _storage = storage;
        _agent   = agent;
        LoadStrategies();
    }

    // ── Strategy list ────────────────────────────────────────────────────────

    public ObservableCollection<StrategyListItemViewModel> Strategies { get; } = [];

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasActiveStrategy))]
    private StrategyListItemViewModel? _selectedItem;

    partial void OnSelectedItemChanged(StrategyListItemViewModel? value)
    {
        if (value is null) { ClearSession(); return; }
        var file = _storage.LoadAll().FirstOrDefault(s => s.Id == value.Id);
        if (file is not null) LoadSession(file);
    }

    // ── Active session ───────────────────────────────────────────────────────

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(HasActiveStrategy))]
    private StrategyFile? _activeFile;

    public bool HasActiveStrategy => ActiveFile is not null;

    public ObservableCollection<ChatMessage> Messages { get; } = [];

    [ObservableProperty]
    [NotifyPropertyChangedFor(nameof(AlgorithmName))]
    [NotifyPropertyChangedFor(nameof(AlgorithmDescription))]
    [NotifyPropertyChangedFor(nameof(AlgorithmSymbol))]
    [NotifyPropertyChangedFor(nameof(AlgorithmTimeframe))]
    [NotifyPropertyChangedFor(nameof(HasAlgorithm))]
    [NotifyPropertyChangedFor(nameof(EntryConditions))]
    [NotifyPropertyChangedFor(nameof(AlgorithmJson))]
    private StrategyAlgorithm? _algorithm;

    // Convenience props for binding in XAML
    public bool HasAlgorithm           => Algorithm is not null;
    public string AlgorithmName        => Algorithm?.Name        ?? string.Empty;
    public string AlgorithmDescription => Algorithm?.Description ?? string.Empty;
    public string AlgorithmSymbol      => Algorithm?.Symbol      ?? string.Empty;
    public string AlgorithmTimeframe   => Algorithm?.Timeframe   ?? string.Empty;
    public IReadOnlyList<string> EntryConditions =>
        Algorithm?.Entry?.Conditions ?? [];
    public string AlgorithmJson        =>
        Algorithm is null ? string.Empty
        : System.Text.Json.JsonSerializer.Serialize(Algorithm,
            new System.Text.Json.JsonSerializerOptions { WriteIndented = true });

    // ── Input ────────────────────────────────────────────────────────────────

    [ObservableProperty]
    [NotifyCanExecuteChangedFor(nameof(SendCommand))]
    private string _inputText = string.Empty;

    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string _statusText = string.Empty;

    private CancellationTokenSource? _cts;

    // ── Commands ─────────────────────────────────────────────────────────────

    [RelayCommand]
    private void NewStrategy()
    {
        var file = new StrategyFile { Name = "Новая стратегия" };
        _storage.Save(file);
        Strategies.Insert(0, new StrategyListItemViewModel(file));
        SelectedItem = Strategies[0];
    }

    [RelayCommand]
    private void DeleteStrategy(StrategyListItemViewModel? item)
    {
        if (item is null) return;
        _storage.Delete(item.Id);
        Strategies.Remove(item);
        if (SelectedItem == item) { SelectedItem = null; ClearSession(); }
    }

    [RelayCommand(CanExecute = nameof(CanSend))]
    private async Task SendAsync()
    {
        if (ActiveFile is null || string.IsNullOrWhiteSpace(InputText)) return;

        var userText = InputText.Trim();
        InputText = string.Empty;

        // Add user message
        var userMsg = new ChatMessage { Role = "user", Content = userText };
        ActiveFile.Messages.Add(userMsg);
        Messages.Add(userMsg);

        IsBusy     = true;
        StatusText = "Hermes думает…";
        _cts       = new CancellationTokenSource(TimeSpan.FromSeconds(120));

        try
        {
            var response = await _agent.SendAsync(ActiveFile.Messages, _cts.Token);

            var assistantMsg = new ChatMessage
            {
                Role         = "assistant",
                Content      = response.Text,
                HasAlgorithm = response.Algorithm is not null
            };

            ActiveFile.Messages.Add(assistantMsg);
            Messages.Add(assistantMsg);

            if (response.Algorithm is not null)
            {
                Algorithm = response.Algorithm;
                ActiveFile.Algorithm = response.Algorithm;

                // Rename list item to strategy name
                if (SelectedItem is not null)
                    SelectedItem.Refresh(ActiveFile);
            }

            _storage.Save(ActiveFile);
            StatusText = string.Empty;
        }
        catch (OperationCanceledException)
        {
            StatusText = "Запрос отменён.";
        }
        catch (Exception ex)
        {
            var errMsg = new ChatMessage
            {
                Role    = "assistant",
                Content = $"Ошибка: {ex.Message}"
            };
            Messages.Add(errMsg);
            ActiveFile.Messages.Add(errMsg);
            _storage.Save(ActiveFile);
            StatusText = string.Empty;
        }
        finally
        {
            IsBusy = false;
            _cts?.Dispose();
            _cts = null;
        }
    }

    private bool CanSend() =>
        !IsBusy && HasActiveStrategy && !string.IsNullOrWhiteSpace(InputText);

    [RelayCommand]
    private void CancelSend()
    {
        _cts?.Cancel();
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private void LoadStrategies()
    {
        Strategies.Clear();
        foreach (var f in _storage.LoadAll())
            Strategies.Add(new StrategyListItemViewModel(f));
    }

    private void LoadSession(StrategyFile file)
    {
        ActiveFile = file;
        Messages.Clear();
        foreach (var m in file.Messages) Messages.Add(m);
        Algorithm = file.Algorithm;
    }

    private void ClearSession()
    {
        ActiveFile = null;
        Messages.Clear();
        Algorithm = null;
    }
}
