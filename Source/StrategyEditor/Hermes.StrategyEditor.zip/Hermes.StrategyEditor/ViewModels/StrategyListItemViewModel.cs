using CommunityToolkit.Mvvm.ComponentModel;
using Hermes.StrategyEditor.Models;

namespace Hermes.StrategyEditor.ViewModels;

/// <summary>Lightweight item for the left-panel list.</summary>
public partial class StrategyListItemViewModel : ObservableObject
{
    [ObservableProperty] private string _name;
    [ObservableProperty] private string _subtitle;

    public string Id { get; }

    public StrategyListItemViewModel(StrategyFile file)
    {
        Id       = file.Id;
        _name    = file.Algorithm?.Name ?? file.Name;
        _subtitle = BuildSubtitle(file);
    }

    public void Refresh(StrategyFile file)
    {
        Name     = file.Algorithm?.Name ?? file.Name;
        Subtitle = BuildSubtitle(file);
    }

    private static string BuildSubtitle(StrategyFile f)
    {
        var parts = new List<string>();
        if (f.Algorithm?.Symbol is { } sym) parts.Add(sym);
        if (f.Algorithm?.Timeframe is { } tf) parts.Add(tf);
        parts.Add($"{f.Messages.Count} сообщ.");
        return string.Join(" · ", parts);
    }
}
