# Интеграция Hermes.StrategyEditor в Hermes.Wpf

## 1. Добавить проект в solution

```
dotnet sln add Hermes.StrategyEditor/Hermes.StrategyEditor.csproj
```

## 2. Добавить ссылку из Hermes.Wpf

В `Hermes.Wpf.csproj`:
```xml
<ItemGroup>
  <ProjectReference Include="..\Hermes.StrategyEditor\Hermes.StrategyEditor.csproj"/>
</ItemGroup>
```

## 3. Кнопка в MainWindow.xaml

```xml
<Button Content="Редактор стратегий"
        Click="OpenStrategyEditor_Click"
        Style="{StaticResource ToolbarButtonStyle}"/>
```

## 4. Обработчик в MainWindow.xaml.cs

```csharp
using Hermes.StrategyEditor;

private void OpenStrategyEditor_Click(object sender, RoutedEventArgs e)
    => StrategyEditorLauncher.Open(owner: this);
```

## 5. Папка стратегий

Файлы сохраняются в `<exe dir>/Strategies/*.strategy.json`.

Путь доступен через `StrategyStorageService.StrategiesFolder`.

## Структура файла стратегии

```json
{
  "id": "a1b2c3d4",
  "name": "BTC Breakout Long",
  "created_at": "2026-05-30T10:00:00+03:00",
  "updated_at": "2026-05-30T10:15:00+03:00",
  "messages": [
    { "role": "user",      "content": "Торгую BTC лонг на 15м...", "has_algorithm": false },
    { "role": "assistant", "content": "Понял. Уточните...",         "has_algorithm": false },
    { "role": "assistant", "content": "Алгоритм готов:\n1. ...",    "has_algorithm": true  }
  ],
  "algorithm": {
    "name": "BTC Breakout Long",
    "symbol": "BTCUSDT",
    "timeframe": "15m",
    "entry": { "conditions": ["..."], "side": "LONG", "order_type": "MARKET", "quantity_usdt": 50 },
    "exit":  { "take_profit_percent": 2.0, "stop_loss_percent": 0.8 },
    "risk":  { "leverage": 10, "max_daily_loss_usdt": 100, "max_open_positions": 2 }
  }
}
```

## Зависимости NuGet

| Пакет | Версия |
|-------|--------|
| CommunityToolkit.Mvvm | 8.3.2 |
| System.Text.Json | 8.0.5 (обычно транзитивна) |
