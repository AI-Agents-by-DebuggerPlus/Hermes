using System.Text.Json.Serialization;

namespace Hermes.StrategyEditor.Models;

// ── Persisted strategy file ──────────────────────────────────────────────────

public class StrategyFile
{
    [JsonPropertyName("id")]
    public string Id { get; set; } = Guid.NewGuid().ToString("N")[..8];

    [JsonPropertyName("name")]
    public string Name { get; set; } = "Новая стратегия";

    [JsonPropertyName("created_at")]
    public DateTimeOffset CreatedAt { get; set; } = DateTimeOffset.Now;

    [JsonPropertyName("updated_at")]
    public DateTimeOffset UpdatedAt { get; set; } = DateTimeOffset.Now;

    [JsonPropertyName("messages")]
    public List<ChatMessage> Messages { get; set; } = [];

    [JsonPropertyName("algorithm")]
    public StrategyAlgorithm? Algorithm { get; set; }
}

// ── Chat message ─────────────────────────────────────────────────────────────

public class ChatMessage
{
    [JsonPropertyName("role")]
    public string Role { get; set; } = "user"; // "user" | "assistant"

    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;

    [JsonPropertyName("has_algorithm")]
    public bool HasAlgorithm { get; set; }

    [JsonIgnore]
    public bool IsUser => Role == "user";

    [JsonIgnore]
    public bool IsAssistant => Role == "assistant";
}

// ── Algorithm JSON produced by agent ─────────────────────────────────────────

public class StrategyAlgorithm
{
    [JsonPropertyName("name")]
    public string? Name { get; set; }

    [JsonPropertyName("description")]
    public string? Description { get; set; }

    [JsonPropertyName("market")]
    public string? Market { get; set; }

    [JsonPropertyName("symbol")]
    public string? Symbol { get; set; }

    [JsonPropertyName("timeframe")]
    public string? Timeframe { get; set; }

    [JsonPropertyName("entry")]
    public EntryBlock? Entry { get; set; }

    [JsonPropertyName("exit")]
    public ExitBlock? Exit { get; set; }

    [JsonPropertyName("risk")]
    public RiskBlock? Risk { get; set; }

    [JsonPropertyName("notes")]
    public string? Notes { get; set; }
}

public class EntryBlock
{
    [JsonPropertyName("conditions")]
    public List<string> Conditions { get; set; } = [];

    [JsonPropertyName("side")]
    public string? Side { get; set; }

    [JsonPropertyName("order_type")]
    public string? OrderType { get; set; }

    [JsonPropertyName("quantity_usdt")]
    public decimal? QuantityUsdt { get; set; }
}

public class ExitBlock
{
    [JsonPropertyName("take_profit_percent")]
    public decimal? TakeProfitPercent { get; set; }

    [JsonPropertyName("stop_loss_percent")]
    public decimal? StopLossPercent { get; set; }

    [JsonPropertyName("conditions")]
    public List<string> Conditions { get; set; } = [];
}

public class RiskBlock
{
    [JsonPropertyName("max_daily_loss_usdt")]
    public decimal? MaxDailyLossUsdt { get; set; }

    [JsonPropertyName("max_open_positions")]
    public int? MaxOpenPositions { get; set; }

    [JsonPropertyName("leverage")]
    public int? Leverage { get; set; }
}
