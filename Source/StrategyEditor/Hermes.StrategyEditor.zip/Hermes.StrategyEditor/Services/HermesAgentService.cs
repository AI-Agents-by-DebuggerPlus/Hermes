using System.Diagnostics;
using System.Text;
using System.Text.Json;
using System.Text.RegularExpressions;
using Hermes.StrategyEditor.Models;

namespace Hermes.StrategyEditor.Services;

/// <summary>
/// Sends prompts to Hermes CLI via WSL and parses the response.
/// Mirrors the pattern used in Hermes.Wpf (process-based IPC).
/// </summary>
public partial class HermesAgentService
{
    // ── System prompt ────────────────────────────────────────────────────────

    private const string SystemPrompt = """
        Ты — Hermes, ассистент-трейдер. Помогаешь пользователю создать торговую стратегию для USDT-M Futures (Binance Demo).

        Пользователь описывает стратегию свободным текстом. Уточняй детали через диалог — по одному вопросу за раз.
        Когда стратегия достаточно определена, выдай:
        1. Пошаговый алгоритм на русском языке
        2. JSON-структуру в теге <strategy_json>...</strategy_json>

        Формат JSON:
        {
          "name": "...",
          "description": "...",
          "market": "futures",
          "symbol": "BTCUSDT",
          "timeframe": "15m",
          "entry": {
            "conditions": ["условие 1"],
            "side": "LONG | SHORT | BOTH",
            "order_type": "MARKET | LIMIT",
            "quantity_usdt": 50
          },
          "exit": {
            "take_profit_percent": 1.5,
            "stop_loss_percent": 0.8,
            "conditions": []
          },
          "risk": {
            "max_daily_loss_usdt": 100,
            "max_open_positions": 2,
            "leverage": 10
          },
          "notes": "..."
        }

        Не выдавай JSON пока стратегия не определена достаточно.
        При обновлении — всегда выдавай полный JSON заново.
        """;

    // ── Agent call ───────────────────────────────────────────────────────────

    /// <summary>
    /// Sends the conversation to Hermes CLI and returns the raw text response.
    /// </summary>
    public async Task<AgentResponse> SendAsync(
        IReadOnlyList<ChatMessage> history,
        CancellationToken ct = default)
    {
        var prompt = BuildPrompt(history);
        var raw = await RunHermesAsync(prompt, ct);
        return ParseResponse(raw);
    }

    // ── Prompt building ──────────────────────────────────────────────────────

    private static string BuildPrompt(IReadOnlyList<ChatMessage> history)
    {
        var sb = new StringBuilder();
        sb.AppendLine("[SYSTEM]");
        sb.AppendLine(SystemPrompt);
        sb.AppendLine();

        foreach (var msg in history)
        {
            sb.AppendLine(msg.IsUser ? "[USER]" : "[ASSISTANT]");
            sb.AppendLine(msg.Content);
            sb.AppendLine();
        }

        sb.AppendLine("[ASSISTANT]");
        return sb.ToString();
    }

    // ── WSL process ──────────────────────────────────────────────────────────

    private static async Task<string> RunHermesAsync(string prompt, CancellationToken ct)
    {
        // Escape prompt for shell: wrap in single quotes, escape internal singles
        var escaped = prompt.Replace("'", "'\\''");

        var psi = new ProcessStartInfo
        {
            FileName = "wsl",
            Arguments = $"-e bash -c \"echo '{escaped}' | hermes chat\"",
            RedirectStandardOutput = true,
            RedirectStandardError = true,
            UseShellExecute = false,
            CreateNoWindow = true,
            StandardOutputEncoding = Encoding.UTF8
        };

        using var process = Process.Start(psi)
            ?? throw new InvalidOperationException("Не удалось запустить WSL/hermes.");

        var outputTask = process.StandardOutput.ReadToEndAsync(ct);
        await process.WaitForExitAsync(ct);
        return await outputTask;
    }

    // ── Response parsing ─────────────────────────────────────────────────────

    private static AgentResponse ParseResponse(string raw)
    {
        var json = ExtractStrategyJson(raw);
        var text = StrategyJsonTag().Replace(raw, string.Empty).Trim();
        return new AgentResponse(text, json);
    }

    private static StrategyAlgorithm? ExtractStrategyJson(string text)
    {
        var match = StrategyJsonTag().Match(text);
        if (!match.Success) return null;
        try
        {
            return JsonSerializer.Deserialize<StrategyAlgorithm>(
                match.Groups["json"].Value.Trim(),
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
        catch { return null; }
    }

    [GeneratedRegex(@"<strategy_json>(?<json>[\s\S]*?)</strategy_json>")]
    private static partial Regex StrategyJsonTag();
}

// ── Result type ───────────────────────────────────────────────────────────────

public record AgentResponse(string Text, StrategyAlgorithm? Algorithm);
