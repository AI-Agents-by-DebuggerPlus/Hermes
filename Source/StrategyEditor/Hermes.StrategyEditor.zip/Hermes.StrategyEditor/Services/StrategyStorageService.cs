using System.IO;
using System.Text.Json;
using Hermes.StrategyEditor.Models;

namespace Hermes.StrategyEditor.Services;

/// <summary>
/// Persists strategy files as individual JSON files in
/// &lt;AppDir&gt;/Strategies/*.strategy.json
/// </summary>
public class StrategyStorageService
{
    private static readonly JsonSerializerOptions JsonOpts = new()
    {
        WriteIndented = true,
        PropertyNamingPolicy = JsonNamingPolicy.CamelCase
    };

    public string StrategiesFolder { get; }

    public StrategyStorageService()
    {
        var appDir = AppContext.BaseDirectory;
        StrategiesFolder = Path.Combine(appDir, "Strategies");
        Directory.CreateDirectory(StrategiesFolder);
    }

    // ── Public API ───────────────────────────────────────────────────────────

    public IReadOnlyList<StrategyFile> LoadAll()
    {
        var result = new List<StrategyFile>();
        foreach (var path in Directory.EnumerateFiles(StrategiesFolder, "*.strategy.json"))
        {
            try
            {
                var json = File.ReadAllText(path);
                var s = JsonSerializer.Deserialize<StrategyFile>(json, JsonOpts);
                if (s != null) result.Add(s);
            }
            catch { /* skip corrupt file */ }
        }
        return result.OrderByDescending(s => s.UpdatedAt).ToList();
    }

    public void Save(StrategyFile strategy)
    {
        strategy.UpdatedAt = DateTimeOffset.Now;
        var path = GetPath(strategy.Id);
        var json = JsonSerializer.Serialize(strategy, JsonOpts);
        File.WriteAllText(path, json);
    }

    public void Delete(string id)
    {
        var path = GetPath(id);
        if (File.Exists(path)) File.Delete(path);
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private string GetPath(string id) =>
        Path.Combine(StrategiesFolder, $"{id}.strategy.json");
}
