using System.Windows;
using Hermes.StrategyEditor.Views;

namespace Hermes.StrategyEditor;

/// <summary>
/// Public entry point. Call from Hermes.Wpf MainWindow button click.
///
/// Usage in MainWindow.xaml.cs:
///   private void OpenStrategyEditor_Click(object sender, RoutedEventArgs e)
///       => StrategyEditorLauncher.Open(owner: this);
/// </summary>
public static class StrategyEditorLauncher
{
    private static StrategyEditorWindow? _instance;

    /// <summary>
    /// Opens the Strategy Editor. If already open — brings to front.
    /// </summary>
    public static void Open(Window? owner = null)
    {
        if (_instance is { IsVisible: true })
        {
            _instance.Activate();
            return;
        }

        _instance = new StrategyEditorWindow();

        if (owner is not null)
        {
            _instance.Owner = owner;
            _instance.WindowStartupLocation = WindowStartupLocation.CenterOwner;
        }

        _instance.Closed += (_, _) => _instance = null;
        _instance.Show();
    }
}
