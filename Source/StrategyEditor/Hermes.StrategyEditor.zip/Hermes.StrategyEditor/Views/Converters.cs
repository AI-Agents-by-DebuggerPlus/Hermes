using System.Globalization;
using System.Windows;
using System.Windows.Data;
using System.Windows.Media;

namespace Hermes.StrategyEditor.Views;

// ── BoolToVisibility ─────────────────────────────────────────────────────────

[ValueConversion(typeof(bool), typeof(Visibility))]
public class BoolToVisibilityConverter : IValueConverter
{
    public static readonly BoolToVisibilityConverter Instance = new();

    public object Convert(object value, Type t, object p, CultureInfo c) =>
        value is true ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object value, Type t, object p, CultureInfo c) =>
        value is Visibility.Visible;
}

[ValueConversion(typeof(bool), typeof(Visibility))]
public class InverseBoolToVisibilityConverter : IValueConverter
{
    public static readonly InverseBoolToVisibilityConverter Instance = new();

    public object Convert(object value, Type t, object p, CultureInfo c) =>
        value is false ? Visibility.Visible : Visibility.Collapsed;

    public object ConvertBack(object value, Type t, object p, CultureInfo c) =>
        value is not Visibility.Visible;
}

// ── Role → alignment / brush ─────────────────────────────────────────────────

[ValueConversion(typeof(bool), typeof(HorizontalAlignment))]
public class UserToAlignmentConverter : IValueConverter
{
    public static readonly UserToAlignmentConverter Instance = new();

    public object Convert(object value, Type t, object p, CultureInfo c) =>
        value is true ? HorizontalAlignment.Right : HorizontalAlignment.Left;

    public object ConvertBack(object value, Type t, object p, CultureInfo c) =>
        DependencyProperty.UnsetValue;
}

[ValueConversion(typeof(bool), typeof(Brush))]
public class UserToBubbleBrushConverter : IValueConverter
{
    public static readonly UserToBubbleBrushConverter Instance = new();

    public object Convert(object value, Type t, object p, CultureInfo c) =>
        value is true
            ? new SolidColorBrush(Color.FromRgb(0xE1, 0xF5, 0xEE))   // teal-50
            : new SolidColorBrush(Color.FromRgb(0xF5, 0xF4, 0xF0));  // gray-50

    public object ConvertBack(object value, Type t, object p, CultureInfo c) =>
        DependencyProperty.UnsetValue;
}

// ── Null/empty → Visibility ──────────────────────────────────────────────────

public class NullToVisibilityConverter : IValueConverter
{
    public static readonly NullToVisibilityConverter Instance = new();

    public object Convert(object value, Type t, object p, CultureInfo c) =>
        value is null || (value is string s && string.IsNullOrWhiteSpace(s))
            ? Visibility.Collapsed : Visibility.Visible;

    public object ConvertBack(object value, Type t, object p, CultureInfo c) =>
        DependencyProperty.UnsetValue;
}
