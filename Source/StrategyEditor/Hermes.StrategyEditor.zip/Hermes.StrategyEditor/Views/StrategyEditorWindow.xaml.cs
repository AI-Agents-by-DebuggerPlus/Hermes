using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;
using System.Windows.Media;
using Hermes.StrategyEditor.Services;
using Hermes.StrategyEditor.ViewModels;

namespace Hermes.StrategyEditor.Views;

public partial class StrategyEditorWindow : Window
{
    public StrategyEditorWindow()
    {
        InitializeComponent();

        var storage = new StrategyStorageService();
        var agent   = new HermesAgentService();
        DataContext  = new StrategyEditorViewModel(storage, agent);

        // Auto-scroll chat to bottom when new messages arrive
        if (DataContext is StrategyEditorViewModel vm)
        {
            vm.Messages.CollectionChanged += Messages_CollectionChanged;
        }
    }

    private void Messages_CollectionChanged(object? sender, NotifyCollectionChangedEventArgs e)
    {
        if (e.Action == NotifyCollectionChangedAction.Add)
            Dispatcher.InvokeAsync(() => MessagesScroll.ScrollToBottom(),
                System.Windows.Threading.DispatcherPriority.Background);
    }
}

// ── Attached property: Send on Enter (Shift+Enter = newline) ─────────────────

public static class InputBoxHelper
{
    public static readonly DependencyProperty SendCommandProperty =
        DependencyProperty.RegisterAttached(
            "SendCommand",
            typeof(ICommand),
            typeof(InputBoxHelper),
            new PropertyMetadata(null, OnSendCommandChanged));

    public static void SetSendCommand(UIElement element, ICommand value) =>
        element.SetValue(SendCommandProperty, value);

    public static ICommand GetSendCommand(UIElement element) =>
        (ICommand)element.GetValue(SendCommandProperty);

    private static void OnSendCommandChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
    {
        if (d is TextBox tb)
            tb.PreviewKeyDown += TextBox_PreviewKeyDown;
    }

    private static void TextBox_PreviewKeyDown(object sender, KeyEventArgs e)
    {
        if (e.Key != Key.Enter || Keyboard.Modifiers.HasFlag(ModifierKeys.Shift)) return;
        e.Handled = true;
        if (sender is TextBox tb)
        {
            var cmd = GetSendCommand(tb);
            if (cmd?.CanExecute(null) == true) cmd.Execute(null);
        }
    }
}

// ── AlgorithmSection: reusable header+content block ─────────────────────────

public class AlgorithmSection : ContentControl
{
    public static readonly DependencyProperty HeaderProperty =
        DependencyProperty.Register(nameof(Header), typeof(string), typeof(AlgorithmSection));

    public string Header
    {
        get => (string)GetValue(HeaderProperty);
        set => SetValue(HeaderProperty, value);
    }

    static AlgorithmSection()
    {
        DefaultStyleKeyProperty.OverrideMetadata(
            typeof(AlgorithmSection),
            new FrameworkPropertyMetadata(typeof(AlgorithmSection)));
    }
}

// ── AlgoTag: colored badge ───────────────────────────────────────────────────

public class AlgoTag : FrameworkElement
{
    public static readonly DependencyProperty LabelProperty =
        DependencyProperty.Register(nameof(Label), typeof(string), typeof(AlgoTag));

    public static readonly DependencyProperty ColorProperty =
        DependencyProperty.Register(nameof(Color), typeof(string), typeof(AlgoTag),
            new PropertyMetadata("Gray"));

    public string Label { get => (string)GetValue(LabelProperty); set => SetValue(LabelProperty, value); }
    public string Color { get => (string)GetValue(ColorProperty); set => SetValue(ColorProperty, value); }
}

// ── AlgoKv: key/value row ────────────────────────────────────────────────────

public class AlgoKv : FrameworkElement
{
    public static readonly DependencyProperty KeyProperty =
        DependencyProperty.Register(nameof(Key), typeof(string), typeof(AlgoKv));

    public static readonly DependencyProperty ValueProperty =
        DependencyProperty.Register(nameof(Value), typeof(object), typeof(AlgoKv));

    public string Key   { get => (string)GetValue(KeyProperty);  set => SetValue(KeyProperty, value); }
    public object Value { get => GetValue(ValueProperty);         set => SetValue(ValueProperty, value); }
}
