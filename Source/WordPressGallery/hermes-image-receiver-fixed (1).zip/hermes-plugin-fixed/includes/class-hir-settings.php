<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

if ( class_exists( 'HIR_Settings', false ) ) {
    return;
}

class HIR_Settings {

    public static function init() {
        add_action( 'admin_menu',  [ __CLASS__, 'add_menu'       ] );
        add_action( 'admin_init',  [ __CLASS__, 'register_settings' ] );
        add_action( 'admin_enqueue_scripts', [ __CLASS__, 'enqueue_admin_assets' ] );
    }

    public static function add_menu() {
        add_options_page(
            'Hermes Image Receiver',
            'Hermes Receiver',
            'manage_options',
            'hermes-image-receiver',
            [ __CLASS__, 'render_page' ]
        );
    }

    public static function enqueue_admin_assets( $hook ) {
        if ( $hook !== 'settings_page_hermes-image-receiver' ) return;
        wp_enqueue_style(
            'hir-admin',
            HIR_PLUGIN_URL . 'assets/css/admin.css',
            [],
            HIR_VERSION
        );
        wp_enqueue_script(
            'hir-admin',
            HIR_PLUGIN_URL . 'assets/js/admin.js',
            [ 'jquery' ],
            HIR_VERSION,
            true
        );
        wp_localize_script( 'hir-admin', 'hirAdmin', [
            'ajaxUrl' => admin_url( 'admin-ajax.php' ),
            'nonce'   => wp_create_nonce( 'hir_admin_nonce' ),
            'restUrl' => rest_url( 'hermes/v1/' ),
            'token'   => get_option( 'hir_secret_token' ),
        ] );
    }

    public static function register_settings() {
        $fields = [
            'hir_ws_port'          => [ 'sanitize_callback' => 'absint'            ],
            'hir_ws_host'          => [ 'sanitize_callback' => 'sanitize_text_field' ],
            'hir_max_images'       => [ 'sanitize_callback' => 'absint'            ],
            'hir_save_to_disk'     => [ 'sanitize_callback' => 'absint'            ],
            'hir_upload_subdir'    => [ 'sanitize_callback' => 'sanitize_file_name' ],
            'hir_allowed_channels' => [ 'sanitize_callback' => 'sanitize_text_field' ],
            'hir_secret_token'     => [ 'sanitize_callback' => 'sanitize_text_field' ],
        ];
        foreach ( $fields as $key => $args ) {
            register_setting( 'hir_settings_group', $key, $args );
        }
    }

    public static function render_page() {
        if ( ! current_user_can( 'manage_options' ) ) return;
        $token = get_option( 'hir_secret_token' );
        $port  = get_option( 'hir_ws_port', 8765 );
        ?>
        <div class="wrap hir-admin-wrap">
            <h1>Hermes Image Receiver</h1>

            <div class="hir-status-bar">
                <span class="hir-status-dot" id="hir-status-dot"></span>
                <span id="hir-status-text">Проверка сервера…</span>
                <button class="button button-secondary" id="hir-refresh-status">↻ Обновить</button>
            </div>

            <div class="hir-grid">
                <div class="hir-card">
                    <h2>Настройки WebSocket-сервера</h2>
                    <form method="post" action="options.php">
                        <?php settings_fields( 'hir_settings_group' ); ?>
                        <table class="form-table">
                            <tr>
                                <th>Хост</th>
                                <td><input type="text" name="hir_ws_host"
                                    value="<?php echo esc_attr( get_option('hir_ws_host','0.0.0.0') ); ?>"
                                    class="regular-text" /></td>
                            </tr>
                            <tr>
                                <th>Порт</th>
                                <td><input type="number" name="hir_ws_port"
                                    value="<?php echo esc_attr( $port ); ?>"
                                    min="1024" max="65535" class="small-text" /></td>
                            </tr>
                            <tr>
                                <th>Макс. изображений в галерее</th>
                                <td><input type="number" name="hir_max_images"
                                    value="<?php echo esc_attr( get_option('hir_max_images',50) ); ?>"
                                    min="1" max="1000" class="small-text" /></td>
                            </tr>
                            <tr>
                                <th>Сохранять на диск</th>
                                <td><input type="checkbox" name="hir_save_to_disk" value="1"
                                    <?php checked( 1, get_option('hir_save_to_disk',1) ); ?> />
                                    <span class="description">Сохранять изображения в папку uploads</span>
                                </td>
                            </tr>
                            <tr>
                                <th>Подпапка uploads</th>
                                <td><input type="text" name="hir_upload_subdir"
                                    value="<?php echo esc_attr( get_option('hir_upload_subdir','hermes-images') ); ?>"
                                    class="regular-text" /></td>
                            </tr>
                            <tr>
                                <th>Разрешённые каналы</th>
                                <td><input type="text" name="hir_allowed_channels"
                                    value="<?php echo esc_attr( get_option('hir_allowed_channels','') ); ?>"
                                    class="regular-text" placeholder="channel1, channel2 (пусто = все)" /></td>
                            </tr>
                            <tr>
                                <th>Секретный токен</th>
                                <td>
                                    <input type="text" name="hir_secret_token"
                                        value="<?php echo esc_attr( $token ); ?>"
                                        class="regular-text" id="hir-token-field" readonly />
                                    <button type="button" class="button" id="hir-regen-token">Сгенерировать новый</button>
                                    <p class="description">Укажите этот токен в настройках Hermes.Wpf</p>
                                </td>
                            </tr>
                        </table>
                        <?php submit_button( 'Сохранить настройки' ); ?>
                    </form>
                </div>

                <div class="hir-card">
                    <h2>Инструкция для Hermes.Wpf</h2>
                    <p>Укажите в настройках Hermes.Wpf следующие параметры:</p>
                    <div class="hir-code-block">
                        <strong>WebSocket URL:</strong><br>
                        <code>ws://<?php echo esc_html( $_SERVER['HTTP_HOST'] ?? 'your-site.com' ); ?>:<?php echo esc_html( $port ); ?></code>
                    </div>
                    <div class="hir-code-block">
                        <strong>REST API Endpoint (альтернатива):</strong><br>
                        <code><?php echo esc_html( rest_url('hermes/v1/image') ); ?></code>
                    </div>
                    <div class="hir-code-block">
                        <strong>Token:</strong><br>
                        <code><?php echo esc_html( $token ); ?></code>
                    </div>
                    <h3>Шорткод для страницы</h3>
                    <div class="hir-code-block">
                        <code>[hermes_gallery]</code><br>
                        <code>[hermes_gallery channel="camera1" max="10" autoconnect="true"]</code>
                    </div>
                    <h3>Формат JSON-сообщения от Hermes.Wpf</h3>
                    <pre class="hir-pre">{
  "token":    "<?php echo esc_html( $token ); ?>",
  "channel":  "default",
  "filename": "image.png",
  "mime":     "image/png",
  "data":     "&lt;base64-encoded image data&gt;",
  "meta": {
    "width":  1920,
    "height": 1080,
    "timestamp": "2024-01-01T12:00:00Z"
  }
}</pre>
                </div>
            </div>

            <div class="hir-card hir-full">
                <h2>Последние полученные изображения</h2>
                <div id="hir-recent-images"><p>Загрузка…</p></div>
                <button class="button button-danger" id="hir-clear-all">🗑 Очистить всё</button>
            </div>
        </div>
        <?php
    }
}
