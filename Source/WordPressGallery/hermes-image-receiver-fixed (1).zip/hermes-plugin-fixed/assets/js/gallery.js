/**
 * Hermes Image Receiver — Frontend Gallery
 * WebSocket client + REST polling fallback + lightbox + fullscreen
 */
(function () {
  'use strict';

  const galleries = {};

  /* ── Init ───────────────────────────────────────────── */
  function initAll() {
    document.querySelectorAll('.hir-gallery-wrap').forEach(initGallery);
  }

  function initGallery(wrap) {
    const uid = wrap.dataset.uid;
    if (galleries[uid]) return;

    let cfg = {};
    if (wrap.dataset.hirConfig) {
      try { cfg = JSON.parse(wrap.dataset.hirConfig); } catch (e) { cfg = {}; }
    } else {
      const cfgKey = 'hirConfig_' + uid.replace(/-/g, '_');
      cfg = window[cfgKey] || {};
    }

    const state = {
      uid,
      wrap,
      ws:           null,
      pollTimer:    null,
      connected:    false,
      images:       [],
      lightboxIdx:  -1,
      channel:      cfg.channel     || wrap.dataset.channel     || '',
      max:          parseInt(cfg.max || wrap.dataset.max || 20),
      autoconnect:  (cfg.autoconnect !== undefined ? cfg.autoconnect : wrap.dataset.autoconnect) !== 'false',
      wsPort:       parseInt(cfg.wsPort  || wrap.dataset.wsPort || 8765),
      wsHost:       cfg.wsHost  || location.hostname,
      restUrl:      cfg.restUrl || '/wp-json/hermes/v1/',
      token:        cfg.token   || '',
      layout:       cfg.layout  || 'grid',
      lastId:       0,
      // fullscreen state
      isFullscreen: false,
      fsLive:       false,   // show new images full-screen automatically
    };

    galleries[uid] = state;
    bindControls(state);

    if (state.autoconnect) connectWS(state);
    fetchImages(state);
  }

  /* ── WebSocket ──────────────────────────────────────── */
  function connectWS(state) {
    if (state.ws && state.ws.readyState <= 1) return;

    if (location.protocol === 'https:') {
      setLed(state, 'connected');
      setStatus(state, 'HTTPS: изображения через REST API (опрос каждые 3 с). Hermes.Wpf отправляет снимки на сервер.');
      updateConnectBtn(state, true);
      startPolling(state);
      return;
    }

    setLed(state, 'connecting');
    setStatus(state, `Подключение к ws://${state.wsHost}:${state.wsPort}…`);

    const url = `ws://${state.wsHost}:${state.wsPort}`;
    let ws;
    try { ws = new WebSocket(url); }
    catch (e) {
      setLed(state, 'error');
      setStatus(state, `Ошибка WebSocket: ${e.message}. Используется REST-опрос.`);
      startPolling(state);
      return;
    }

    state.ws = ws;

    ws.onopen = () => {
      state.connected = true;
      setLed(state, 'connected');
      setStatus(state, `Подключено к Hermes.Wpf (ws://${state.wsHost}:${state.wsPort})`);
      updateConnectBtn(state, true);
      stopPolling(state);
      ws.send(JSON.stringify({ type: 'subscribe', channel: state.channel, token: state.token }));
    };

    ws.onmessage = (evt) => {
      try { handleMessage(state, JSON.parse(evt.data)); } catch (e) {}
    };

    ws.onclose = (evt) => {
      state.connected = false;
      setLed(state, '');
      setStatus(state, `Отключено. Код: ${evt.code}. Переподключение через 5 с…`);
      updateConnectBtn(state, false);
      setTimeout(() => { if (galleries[state.uid] && !state.connected) connectWS(state); }, 5000);
      startPolling(state);
    };

    ws.onerror = () => {
      setLed(state, 'error');
      setStatus(state, 'Ошибка WebSocket. Используется REST-опрос.');
      startPolling(state);
    };
  }

  function disconnectWS(state) {
    stopPolling(state);
    if (state.ws) { state.ws.onclose = null; state.ws.close(); state.ws = null; }
    state.connected = false;
    setLed(state, '');
    setStatus(state, 'Отключено.');
    updateConnectBtn(state, false);
  }

  /* ── Message handler ────────────────────────────────── */
  function handleMessage(state, msg) {
    if (msg.type !== 'image' && !msg.data) return;
    if (state.channel && msg.channel && msg.channel !== state.channel) return;

    const url = msg.url || (msg.data ? 'data:' + (msg.mime || 'image/png') + ';base64,' + msg.data : null);
    if (!url) return;

    const item = {
      id:         msg.id || Date.now(),
      url,
      channel:    msg.channel || 'default',
      filename:   msg.filename || 'image.png',
      created_at: msg.created_at || new Date().toISOString(),
      meta:       msg.meta || {},
    };

    prependImage(state, item);
  }

  /* ── REST polling ───────────────────────────────────── */
  function startPolling(state) {
    if (state.pollTimer) return;
    state.pollTimer = setInterval(() => fetchImages(state), 3000);
  }

  function stopPolling(state) {
    if (state.pollTimer) { clearInterval(state.pollTimer); state.pollTimer = null; }
  }

  function fetchImages(state) {
    let url = state.restUrl + 'images?limit=20';
    if (state.channel) url += '&channel=' + encodeURIComponent(state.channel);
    if (state.lastId)  url += '&since=' + state.lastId;

    fetch(url)
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!data || !data.images) return;
        const items = [...data.images].reverse();
        items.forEach(img => prependImage(state, img, false));
        if (items.length) {
          const maxId = Math.max(...items.map(i => i.id));
          state.lastId = Math.max(state.lastId, maxId);
        }
      })
      .catch(() => {});
  }

  /* ── Render ─────────────────────────────────────────── */
  function prependImage(state, item, flash = true) {
    if (state.images.find(i => i.id === item.id)) return;

    state.images.unshift(item);
    if (state.images.length > state.max) state.images = state.images.slice(0, state.max);
    if (typeof item.id === 'number') state.lastId = Math.max(state.lastId, item.id);

    renderGallery(state, flash ? item.id : null);

    // Fullscreen-live: show new image immediately in fullscreen overlay
    if (flash && state.fsLive) {
      openFsOverlay(state, item);
    }
  }

  function renderGallery(state, flashId) {
    const container = state.wrap.querySelector(`.hir-images[data-uid="${state.uid}"]`);
    if (!container) return;

    const empty = container.querySelector('.hir-empty-state');
    if (empty) empty.remove();

    const existing = new Map();
    container.querySelectorAll('.hir-img-item').forEach(el => existing.set(el.dataset.id, el));

    existing.forEach((el, id) => {
      if (!state.images.find(i => String(i.id) === id)) el.remove();
    });

    state.images.forEach((img, idx) => {
      const idStr = String(img.id);
      let el = existing.get(idStr);
      if (!el) {
        el = buildImageEl(state, img, idx);
        const ref = container.children[idx] || null;
        container.insertBefore(el, ref);
      }
      if (img.id === flashId) {
        el.classList.remove('hir-new');
        void el.offsetWidth;
        el.classList.add('hir-new');
      }
    });

    const counter = state.wrap.querySelector(`.hir-counter[data-uid="${state.uid}"]`);
    if (counter) counter.textContent = `${state.images.length} фото`;
  }

  function buildImageEl(state, img, idx) {
    const el = document.createElement('div');
    el.className  = 'hir-img-item';
    el.dataset.id  = String(img.id);
    el.dataset.idx = idx;
    el.innerHTML = `
      <img src="${escHtml(img.url)}" alt="${escHtml(img.filename)}" loading="lazy" />
      <div class="hir-img-meta">
        <span class="hir-img-channel">#${escHtml(img.channel)}</span>
        <span>${escHtml(formatTime(img.created_at))}</span>
      </div>`;
    el.addEventListener('click', () => openLightbox(state, idx));
    return el;
  }

  /* ── Lightbox ───────────────────────────────────────── */
  function openLightbox(state, idx) {
    state.lightboxIdx = idx;
    const lb = state.wrap.querySelector(`.hir-lightbox[data-uid="${state.uid}"]`);
    if (!lb) return;
    lb.style.display = 'flex';
    renderLightbox(state);
    document.addEventListener('keydown', state._lbKey = e => {
      if (e.key === 'ArrowRight') { state.lightboxIdx = (state.lightboxIdx + 1) % state.images.length; renderLightbox(state); }
      if (e.key === 'ArrowLeft')  { state.lightboxIdx = (state.lightboxIdx - 1 + state.images.length) % state.images.length; renderLightbox(state); }
      if (e.key === 'Escape')     closeLightbox(state);
    });
  }

  function renderLightbox(state) {
    const lb  = state.wrap.querySelector(`.hir-lightbox[data-uid="${state.uid}"]`);
    if (!lb) return;
    const img = state.images[state.lightboxIdx];
    if (!img) return;
    lb.querySelector('.hir-lightbox-img').src = img.url;
    const m = img.meta || {};
    lb.querySelector('.hir-lightbox-meta').textContent =
      [img.filename, m.width ? `${m.width}×${m.height}` : '', formatTime(img.created_at)].filter(Boolean).join(' · ');
  }

  function closeLightbox(state) {
    const lb = state.wrap.querySelector(`.hir-lightbox[data-uid="${state.uid}"]`);
    if (lb) lb.style.display = 'none';
    if (state._lbKey) document.removeEventListener('keydown', state._lbKey);
  }

  /* ── Fullscreen gallery ─────────────────────────────── */
  function enterFullscreen(state) {
    const el = state.wrap;
    const req = el.requestFullscreen || el.webkitRequestFullscreen || el.mozRequestFullScreen || el.msRequestFullscreen;
    if (req) {
      req.call(el).catch(() => {});
    } else {
      // Fallback: CSS fullscreen simulation
      el.classList.add('hir-simulated-fullscreen');
    }
    state.isFullscreen = true;
    updateFsBtn(state);
  }

  function exitFullscreen(state) {
    if (document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement) {
      const exit = document.exitFullscreen || document.webkitExitFullscreen || document.mozCancelFullScreen || document.msExitFullscreen;
      if (exit) exit.call(document).catch(() => {});
    }
    state.wrap.classList.remove('hir-simulated-fullscreen');
    state.isFullscreen = false;
    updateFsBtn(state);
  }

  function toggleFullscreen(state) {
    if (state.isFullscreen) exitFullscreen(state);
    else enterFullscreen(state);
  }

  function updateFsBtn(state) {
    const btn = state.wrap.querySelector(`.hir-btn-fullscreen[data-uid="${state.uid}"]`);
    if (!btn) return;
    btn.textContent   = state.isFullscreen ? '⛶ Свернуть' : '⛶ На весь экран';
    btn.title         = state.isFullscreen ? 'Выйти из полноэкранного режима' : 'Развернуть на весь экран';
    btn.classList.toggle('active', state.isFullscreen);
  }

  /* ── Fullscreen-live overlay ────────────────────────── */
  // Shows each new image in a full-viewport overlay for a few seconds
  let _fsOverlayTimer = null;

  function openFsOverlay(state, item) {
    let overlay = state.wrap.querySelector('.hir-fs-overlay');
    if (!overlay) return;

    const img  = overlay.querySelector('.hir-fs-overlay-img');
    const meta = overlay.querySelector('.hir-fs-overlay-meta');

    img.src = item.url;
    const m = item.meta || {};
    meta.textContent = [
      item.filename,
      m.width ? `${m.width}×${m.height}` : '',
      formatTime(item.created_at),
    ].filter(Boolean).join(' · ');

    overlay.classList.add('hir-fs-overlay--visible');

    // Auto-hide after 5 s (reset timer if new image arrives)
    if (_fsOverlayTimer) clearTimeout(_fsOverlayTimer);
    _fsOverlayTimer = setTimeout(() => closeFsOverlay(state), 5000);
  }

  function closeFsOverlay(state) {
    const overlay = state.wrap.querySelector('.hir-fs-overlay');
    if (overlay) overlay.classList.remove('hir-fs-overlay--visible');
    if (_fsOverlayTimer) { clearTimeout(_fsOverlayTimer); _fsOverlayTimer = null; }
  }

  function toggleFsLive(state) {
    state.fsLive = !state.fsLive;
    const btn = state.wrap.querySelector(`.hir-btn-fslive[data-uid="${state.uid}"]`);
    if (btn) {
      btn.textContent = state.fsLive ? '⬛ Стоп авто-показ' : '▶ Авто-показ';
      btn.classList.toggle('active', state.fsLive);
      btn.title = state.fsLive
        ? 'Отключить: новые изображения не будут показываться на весь экран'
        : 'Включить: каждое новое изображение будет открываться на весь экран';
    }
  }

  /* ── Controls binding ───────────────────────────────── */
  function bindControls(state) {
    const uid = state.uid;

    // Connect
    const btnConn = state.wrap.querySelector(`.hir-btn-connect[data-uid="${uid}"]`);
    if (btnConn) {
      btnConn.addEventListener('click', () => {
        if (state.connected || (state.ws && state.ws.readyState <= 1)) disconnectWS(state);
        else connectWS(state);
      });
    }

    // Clear
    const btnClear = state.wrap.querySelector(`.hir-btn-clear[data-uid="${uid}"]`);
    if (btnClear) {
      btnClear.addEventListener('click', () => {
        state.images = [];
        state.lastId = 0;
        const container = state.wrap.querySelector(`.hir-images[data-uid="${uid}"]`);
        if (container) container.innerHTML = `<div class="hir-empty-state">
          <div class="hir-empty-icon">📡</div>
          <p>Ожидание изображений от Hermes.Wpf…</p></div>`;
        const counter = state.wrap.querySelector(`.hir-counter[data-uid="${uid}"]`);
        if (counter) counter.textContent = '0 фото';
      });
    }

    // Fullscreen button
    const btnFs = state.wrap.querySelector(`.hir-btn-fullscreen[data-uid="${uid}"]`);
    if (btnFs) {
      btnFs.addEventListener('click', () => toggleFullscreen(state));
    }

    // Fullscreen-live button
    const btnFsLive = state.wrap.querySelector(`.hir-btn-fslive[data-uid="${uid}"]`);
    if (btnFsLive) {
      btnFsLive.addEventListener('click', () => toggleFsLive(state));
    }

    // Sync isFullscreen flag when user presses Escape
    const onFsChange = () => {
      const isFull = !!(document.fullscreenElement || document.webkitFullscreenElement || document.mozFullScreenElement);
      if (!isFull && state.isFullscreen) {
        state.wrap.classList.remove('hir-simulated-fullscreen');
        state.isFullscreen = false;
        updateFsBtn(state);
      }
    };
    document.addEventListener('fullscreenchange',       onFsChange);
    document.addEventListener('webkitfullscreenchange', onFsChange);
    document.addEventListener('mozfullscreenchange',    onFsChange);

    // Lightbox
    const lb = state.wrap.querySelector(`.hir-lightbox[data-uid="${uid}"]`);
    if (lb) {
      lb.querySelector('.hir-lightbox-close').addEventListener('click',   () => closeLightbox(state));
      lb.querySelector('.hir-lightbox-overlay').addEventListener('click', () => closeLightbox(state));
      lb.querySelector('.hir-lightbox-prev').addEventListener('click', () => {
        state.lightboxIdx = (state.lightboxIdx - 1 + state.images.length) % state.images.length;
        renderLightbox(state);
      });
      lb.querySelector('.hir-lightbox-next').addEventListener('click', () => {
        state.lightboxIdx = (state.lightboxIdx + 1) % state.images.length;
        renderLightbox(state);
      });
    }

    // Fullscreen-live overlay controls
    const fsOverlay = state.wrap.querySelector('.hir-fs-overlay');
    if (fsOverlay) {
      fsOverlay.querySelector('.hir-fs-overlay-close')?.addEventListener('click', () => closeFsOverlay(state));
      fsOverlay.querySelector('.hir-fs-overlay-img')?.addEventListener('click', () => closeFsOverlay(state));
    }
  }

  /* ── Helpers ────────────────────────────────────────── */
  function setLed(state, cls) {
    state.wrap.querySelectorAll(`.hir-led[data-uid="${state.uid}"]`).forEach(el => {
      el.className = 'hir-led ' + cls;
    });
  }
  function setStatus(state, msg) {
    state.wrap.querySelectorAll(`.hir-status-msg[data-uid="${state.uid}"]`).forEach(el => {
      el.textContent = msg;
    });
  }
  function updateConnectBtn(state, isConnected) {
    state.wrap.querySelectorAll(`.hir-btn-connect[data-uid="${state.uid}"]`).forEach(btn => {
      btn.textContent = isConnected ? 'Отключить' : 'Подключить';
      btn.classList.toggle('active', isConnected);
    });
  }
  function formatTime(iso) {
    try { return new Date(iso).toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit', second: '2-digit' }); }
    catch { return ''; }
  }
  function escHtml(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* ── Boot ───────────────────────────────────────────── */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', initAll);
  } else {
    initAll();
  }

  window.HermesReceiver = { initAll, galleries };
})();
