using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Text.Json.Serialization;
using System.Threading;
using System.Threading.Tasks;

namespace Hermes.Wpf.Logging
{
    // ───────────────────────────────────────────────────────────────────────────
    // HermesLogSender
    //
    // Отправляет накопленные логи на WordPress-сайт через REST API плагина.
    // Endpoint: POST /wp-json/hermes/v1/logs
    //
    // Использование:
    //   var sender = new HermesLogSender("https://your-site.com", "secret-token");
    //   sender.Log(LogLevel.Info, "Готово", category: "ImageSender");
    //   await sender.FlushAsync();   // или вызывается автоматически при накоплении
    //
    // Автоматическая отправка: каждые FlushIntervalSeconds секунд ИЛИ
    // при накоплении BatchSize записей.
    // ───────────────────────────────────────────────────────────────────────────

    public sealed class HermesLogSender : IDisposable
    {
        // ── Настройки ──────────────────────────────────────────────────────────

        /// <summary>Базовый URL сайта, например "https://example.com"</summary>
        public string SiteUrl { get; }

        /// <summary>Секретный токен из настроек плагина (hir_secret_token)</summary>
        public string Token { get; }

        /// <summary>Строка-идентификатор источника, отображается в логах на сайте</summary>
        public string Source { get; set; } = "HermesWpf/1.0";

        /// <summary>Отправлять пакет автоматически при накоплении этого числа записей</summary>
        public int BatchSize { get; set; } = 50;

        /// <summary>Интервал автоматической отправки (секунды). 0 — отключить таймер.</summary>
        public int FlushIntervalSeconds { get; set; } = 30;

        // ── Поля ───────────────────────────────────────────────────────────────

        private static readonly HttpClient _http = new HttpClient { Timeout = TimeSpan.FromSeconds(15) };

        private readonly List<LogEntry> _buffer = new List<LogEntry>();
        private readonly SemaphoreSlim  _lock   = new SemaphoreSlim(1, 1);
        private readonly Timer?         _timer;

        private bool _disposed;

        // ── Конструктор ────────────────────────────────────────────────────────

        /// <param name="siteUrl">URL сайта WordPress, например "https://example.com"</param>
        /// <param name="token">Секретный токен из настроек плагина Hermes</param>
        /// <param name="startTimer">Запустить таймер автоматической отправки</param>
        public HermesLogSender(string siteUrl, string token, bool startTimer = true)
        {
            SiteUrl = siteUrl.TrimEnd('/');
            Token   = token;

            if (startTimer && FlushIntervalSeconds > 0)
            {
                var interval = TimeSpan.FromSeconds(FlushIntervalSeconds);
                _timer = new Timer(_ => _ = FlushAsync(), null, interval, interval);
            }
        }

        // ── Публичный API: добавление записей ──────────────────────────────────

        /// <summary>Добавить запись лога в буфер.</summary>
        public void Log(
            LogLevel  level,
            string    message,
            string?   category  = null,
            Exception? exception = null,
            object?   extra     = null)
        {
            if (string.IsNullOrWhiteSpace(message)) return;

            var entry = new LogEntry
            {
                Level     = level.ToString(),
                Message   = message,
                Timestamp = DateTime.UtcNow.ToString("o"),   // ISO 8601
                Category  = category ?? string.Empty,
                Exception = exception?.ToString(),
                Extra     = extra is null
                    ? null
                    : JsonSerializer.Deserialize<Dictionary<string, object>>(
                        JsonSerializer.Serialize(extra)),
            };

            lock (_buffer)
            {
                _buffer.Add(entry);
            }

            // Авто-сброс при достижении порога
            if (_buffer.Count >= BatchSize)
                _ = FlushAsync();
        }

        // ── Удобные перегрузки ─────────────────────────────────────────────────

        public void LogTrace  (string msg, string? cat = null) => Log(LogLevel.Trace,   msg, cat);
        public void LogDebug  (string msg, string? cat = null) => Log(LogLevel.Debug,   msg, cat);
        public void LogInfo   (string msg, string? cat = null) => Log(LogLevel.Info,    msg, cat);
        public void LogWarning(string msg, string? cat = null) => Log(LogLevel.Warning, msg, cat);
        public void LogError  (string msg, Exception? ex = null, string? cat = null) => Log(LogLevel.Error, msg, cat, ex);
        public void LogFatal  (string msg, Exception? ex = null, string? cat = null) => Log(LogLevel.Fatal, msg, cat, ex);

        // ── Отправка ───────────────────────────────────────────────────────────

        /// <summary>
        /// Отправить все накопленные логи на сайт.
        /// Безопасно вызывать из нескольких потоков — внутри используется SemaphoreSlim.
        /// </summary>
        /// <returns>true — если отправка прошла успешно, false — если произошла ошибка.</returns>
        public async Task<bool> FlushAsync(CancellationToken ct = default)
        {
            List<LogEntry> batch;

            lock (_buffer)
            {
                if (_buffer.Count == 0) return true;
                batch = new List<LogEntry>(_buffer);
                _buffer.Clear();
            }

            // Не допускаем параллельных отправок
            await _lock.WaitAsync(ct).ConfigureAwait(false);
            try
            {
                return await SendBatchAsync(batch, ct).ConfigureAwait(false);
            }
            finally
            {
                _lock.Release();
            }
        }

        // ── Внутренняя отправка ────────────────────────────────────────────────

        private async Task<bool> SendBatchAsync(List<LogEntry> entries, CancellationToken ct)
        {
            var url     = $"{SiteUrl}/wp-json/hermes/v1/logs";
            var payload = new LogPayload
            {
                Token   = Token,
                Source  = Source,
                Entries = entries,
            };

            try
            {
                using var request = new HttpRequestMessage(HttpMethod.Post, url);
                request.Headers.Add("X-Hermes-Token", Token);
                request.Content = JsonContent.Create(payload, options: JsonOptions);

                using var response = await _http.SendAsync(request, ct).ConfigureAwait(false);

                if (response.IsSuccessStatusCode)
                    return true;

                // Сервер вернул ошибку — можно добавить fallback-запись в файл
                var body = await response.Content.ReadAsStringAsync(ct).ConfigureAwait(false);
                System.Diagnostics.Debug.WriteLine(
                    $"[HermesLogSender] HTTP {(int)response.StatusCode}: {body}");
                return false;
            }
            catch (OperationCanceledException)
            {
                throw;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"[HermesLogSender] Send failed: {ex.Message}");
                return false;
            }
        }

        // ── JSON ───────────────────────────────────────────────────────────────

        private static readonly JsonSerializerOptions JsonOptions = new JsonSerializerOptions
        {
            PropertyNamingPolicy        = JsonNamingPolicy.CamelCase,
            DefaultIgnoreCondition      = JsonIgnoreCondition.WhenWritingNull,
            WriteIndented               = false,
        };

        // ── IDisposable ────────────────────────────────────────────────────────

        public void Dispose()
        {
            if (_disposed) return;
            _disposed = true;
            _timer?.Dispose();
            // Синхронный сброс при завершении — последняя попытка отправить буфер
            FlushAsync().GetAwaiter().GetResult();
            _lock.Dispose();
        }
    }

    // ── Вспомогательные типы ───────────────────────────────────────────────────

    public enum LogLevel { Trace, Debug, Info, Warning, Error, Fatal }

    internal sealed class LogPayload
    {
        [JsonPropertyName("token")]   public string Token   { get; set; } = "";
        [JsonPropertyName("source")]  public string Source  { get; set; } = "";
        [JsonPropertyName("entries")] public List<LogEntry> Entries { get; set; } = new();
    }

    internal sealed class LogEntry
    {
        [JsonPropertyName("level")]     public string  Level     { get; set; } = "Info";
        [JsonPropertyName("message")]   public string  Message   { get; set; } = "";
        [JsonPropertyName("timestamp")] public string  Timestamp { get; set; } = "";
        [JsonPropertyName("category")]  public string? Category  { get; set; }
        [JsonPropertyName("exception")] public string? Exception { get; set; }
        [JsonPropertyName("extra")]     public Dictionary<string, object>? Extra { get; set; }
    }
}
